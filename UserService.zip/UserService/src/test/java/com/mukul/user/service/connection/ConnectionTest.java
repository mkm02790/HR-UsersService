/**
 * 
 */
package com.mukul.user.service.connection;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author mukul
 *
 * 27-Nov-2022
 */
class ConnectionTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}

/**
 * 
 */
/*
 * package com.mukul.user.service.model;
 * 
 * import org.springframework.http.HttpStatus;
 * 
 * import lombok.AllArgsConstructor; import lombok.Builder; import
 * lombok.Getter; import lombok.NoArgsConstructor; import lombok.Setter;
 * 
 *//**
	 * @author mukul
	 *
	 *         20-Nov-2022
	 *//*
		 * @Getter
		 * 
		 * @Setter
		 * 
		 * @AllArgsConstructor public class APIResponse {
		 * 
		 * private String message; private boolean success; private HttpStatus status;
		 * 
		 * public APIResponse(Builder builder) { this.message = builder.message;
		 * this.success = builder.success; this.status = builder.status; } public String
		 * getMessage() { return message; } public boolean isSuccess() { return success;
		 * } public HttpStatus getStatus() { return status; }
		 * 
		 * @Override public String toString() { return "APIResponse [message=" + message
		 * + ", success=" + success + ", status=" + status + "]"; }
		 * 
		 * public static class Builder { private String message; private boolean
		 * success; private HttpStatus status;
		 * 
		 * public Builder setMessage(String message) { this.message = message; return
		 * this; } public Builder setSuccess(boolean success) { this.success = success;
		 * return this; } public Builder setStatus(HttpStatus status) { this.status =
		 * status; return this; } public Builder() {
		 * 
		 * } public APIResponse build() { return new APIResponse(this);}
		 * 
		 * }
		 * 
		 * 
		 * 
		 * }
		 */